﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Orders.Management.API.Controllers;
using Orders.Management.API.Models;
using System.Net.Http;
using System.Web.Http;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web;
using System.IO;

namespace Orders.Management.API.Tests.Controllers
{
    [TestClass]
    public class OrdersControllerTest
    {
        OrdersController controller = null;
      
        [TestInitialize]
        public void Setup()
        {
            controller = new OrdersController();

            controller.Request = new HttpRequestMessage();

            controller.Request.SetConfiguration(new HttpConfiguration());

            HttpContext.Current = new HttpContext(
                               new HttpRequest(string.Empty, "http://localhost:52841/", string.Empty),
                               new HttpResponse(new StringWriter())
                             );
        }

        /// <summary>
        /// FetchOrder success case
        /// </summary>
        [TestMethod]
        public void FetchOrder_Success()
        {
            int orderNumber = 17890;
            new OrdersController();
            var httpResponse = controller.FetchOrder(orderNumber);
            Order result;
            httpResponse.TryGetContentValue<Order>(out result);
            Assert.IsNotNull(result);
        }

        /// <summary>
        /// FetchOrder failure case
        /// </summary>
        [TestMethod]
        public void FetchOrder_Failure()
        {
            int orderNumber = 123;            
            var httpResponse = controller.FetchOrder(orderNumber);
            Order result;
            httpResponse.TryGetContentValue<Order>(out result);
            Assert.IsNull(result);
        }
    }
}
