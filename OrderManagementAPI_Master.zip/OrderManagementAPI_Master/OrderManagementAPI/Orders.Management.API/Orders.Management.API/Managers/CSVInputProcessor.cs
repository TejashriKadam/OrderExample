﻿using Orders.Management.API.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Orders.Management.API.Models;
using Orders.Management.API.Helpers;
using System.IO;
using System.Xml.Serialization;

namespace Orders.Management.API.Managers
{
    /// <summary>
    /// CSVInputProcessor implments methods of IProcessInput to process input in form of CSV.
    /// </summary>
    public class CSVInputProcessor : IProcessInput
    {
        /// <summary>
        /// Gets input file path
        /// </summary>
        public string filePath
        {
            get { return CommonHelper.ReadInputFilePath(); }
        }

        /// <summary>
        /// Reads input from file and returns order collection
        /// </summary>
        /// <returns></returns>
        public OrderCollection FetchOrder()
        {
            OrderCollection ordersList = new OrderCollection();

            if (!string.IsNullOrWhiteSpace(filePath))
            {

                if (Directory.Exists(filePath) == false)
                {
                    CommonHelper.WriteErrorLog("Invalid input file path");
                    return ordersList;
                }
                //  path is valid, read all files
                List<Order> orders = new List<Order>();
                try
                {
                    // get all file names
                    string[] allOrderFiles = Directory.GetFiles(filePath);

                    foreach (string fileName in allOrderFiles)
                    {
                        // read file content - line  by line
                        string[] allLines = File.ReadAllLines(fileName);

                        if (allLines != null && allLines.Length > 1)
                        {
                            // remove first line as it is a column header   
                            allLines = allLines.Where(a => a != allLines[0]).ToArray();

                            List<OrderDetails> orderDetailsList = new List<OrderDetails>(); // instance for order details list
                            Order order = new Order();
                            OrderDetails details = null;
                            foreach (string line in allLines)    // each line is an order detail
                            {
                                // split line data by delimiter
                                string[] lineData = line.Split(Constants.Delimiter);
                                if (lineData != null && lineData.Length > 0)
                                {
                                    // first column is order number common for all order details in given file
                                    if (order.OrderNumber == 0)
                                    {
                                        order.OrderNumber = string.IsNullOrWhiteSpace(lineData[1]) ? 0 : Convert.ToInt64(lineData[1]);
                                    }
                                    details = GetOrderDetailsFromCsvString(lineData);
                                    orderDetailsList.Add(details);
                                }
                            }
                            order.Details = orderDetailsList;
                            orders.Add(order);
                        }
                    }
                    ordersList.Orders = orders;
                }
                catch (Exception ex)
                {
                    CommonHelper.WriteErrorLog("Exception while reading orders from File..");
                    CommonHelper.WriteErrorLog(ex.ToString());
                }
            }
            return ordersList;
        }

        /// <summary>
        /// Creates and store xml for OrderCollection
        /// </summary>
        /// <param name="ordersList">OrderCollection ordersList</param>
        public void CreateXml(OrderCollection ordersList)
        {
            try
            {
                XmlSerializer serializer = new XmlSerializer(typeof(OrderCollection));

                using (FileStream fs = new FileStream(CommonHelper.ReadXmlOutputDirectoryPath(), FileMode.OpenOrCreate))
                {
                    serializer.Serialize(fs, ordersList);
                }
            }
            catch (Exception ex)
            {
                CommonHelper.WriteErrorLog("Error while serializing ordersList");
                CommonHelper.WriteErrorLog(ex.ToString());
            }
        }

        #region Private Methods
        /// <summary>
        /// Creates order details object from string array objtained by splitting string by delimiter
        /// </summary>
        /// <param name="lineData">string[] lineData</param>
        /// <returns>OrderDetails</returns>
        private static OrderDetails GetOrderDetailsFromCsvString(string[] lineData)
        {
            OrderDetails details = new OrderDetails();
            details.OrderLineNumber = string.IsNullOrWhiteSpace(lineData[2]) ? 0 : Convert.ToInt64(lineData[2]);
            details.ProductNumber = lineData[3];
            details.Quantity = string.IsNullOrWhiteSpace(lineData[4]) ? 0 : Convert.ToInt32(lineData[4]);
            details.Name = lineData[5];
            details.Description = lineData[6];
            details.Price = string.IsNullOrWhiteSpace(lineData[7]) ? 0 : Convert.ToDouble(lineData[7]);
            details.ProductGroup = lineData[8];
            details.OrderDate = string.IsNullOrWhiteSpace(lineData[9]) ? DateTime.MinValue : Convert.ToDateTime(lineData[9]);
            details.CustomerName = lineData[10];
            details.CustomerNumber = string.IsNullOrWhiteSpace(lineData[11]) ? 0 : Convert.ToInt64(lineData[11]);
            return details;
        }



        #endregion
    }
}