﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using Orders.Management.API.Helpers;
using Orders.Management.API.Models;
using System.Web.Http.Results;

namespace Orders.Management.API.Controllers
{
    /// <summary>
    /// API controller for order management
    /// </summary>
    public class OrdersController : ApiController
    {
        /// <summary>
        /// Fetches order as per given orderNumber
        /// </summary>
        /// <param name="orderNumber" type="long">long orderNumber</param>
        /// <returns>Order</returns>
        [HttpGet]
        public HttpResponseMessage FetchOrder(long orderNumber)
        {
            // Get order collection
            OrderCollection ordersList = OrderManagementHelper.GeOrderCollection();

            Order searchOrder = null;
            // search if order present
            if (ordersList != null && ordersList.Orders != null && ordersList.Orders.Count > 0)
            {

                searchOrder= ordersList.Orders.FirstOrDefault(o => o.OrderNumber == orderNumber);
                if(searchOrder != null)
                {
                    return Request.CreateResponse(HttpStatusCode.OK, searchOrder);
                }
            }
            // order not found for given orderNumber, return not found response
            return  Request.CreateResponse(HttpStatusCode.NotFound, searchOrder);
        }

    }
}
