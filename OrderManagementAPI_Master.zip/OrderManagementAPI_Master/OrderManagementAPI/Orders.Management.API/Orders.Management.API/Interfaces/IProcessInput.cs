﻿using Orders.Management.API.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Orders.Management.API.Interfaces
{
    // Interface for methods to be implemented for taking input
    public interface IProcessInput
    {
        OrderCollection FetchOrder();

        void CreateXml(OrderCollection ordersList);
    }
}
