﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Xml.Serialization;

namespace Orders.Management.API.Models
{
    [XmlRoot("OrderCollection")]
    public class Order
    {
        public Order()
        {
            Details = new List<OrderDetails>();
        }
        public long OrderNumber { get; set; }

        [XmlArray("OrderDetails"), XmlArrayItem(typeof(OrderDetails), ElementName = "OrderDetails")]
        public List<OrderDetails> Details { get; set; }
    }
}