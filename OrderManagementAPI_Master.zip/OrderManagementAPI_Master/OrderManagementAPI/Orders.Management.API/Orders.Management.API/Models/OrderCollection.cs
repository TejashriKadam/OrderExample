﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Xml.Serialization;

namespace Orders.Management.API.Models
{
    public class OrderCollection
    {
        public OrderCollection()
        {
            Orders = new List<Order>();
        }

        [XmlArray("Orders"), XmlArrayItem(typeof(Order), ElementName = "Order")]
        public List<Order> Orders { get; set; }
    }
}