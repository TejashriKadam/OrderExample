﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Xml.Serialization;

namespace Orders.Management.API.Models
{
    [XmlRoot("Order")]
    public class OrderDetails
    {
        //  public long OrderNumber { get; set; }
        public long OrderLineNumber { get; set; }
        public string ProductNumber { get; set; }

        public int Quantity { get; set; }

        public string Name { get; set; }

        public string Description { get; set; }

        public double Price { get; set; }
        public string ProductGroup { get; set; }

        public DateTime OrderDate { get; set; }

        public string CustomerName { get; set; }

        public long CustomerNumber { get; set; }
    }
}