﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Orders.Management.API.Helpers
{
    public class Constants
    {
        public const char Delimiter = '|';
        public struct WebConfigKeys
        {
            public const string InputFileDirectory = "InputFileDirectory";

            public const string XmlOutputDirectoryPath = "XmlOutputDirectoryPath";

            public const string LogFilePath = "LogFilePath";

            public const string InputProcessorMode = "InputProcessorMode";
        }
        
    }
}