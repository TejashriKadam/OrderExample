﻿using Orders.Management.API.Interfaces;
using Orders.Management.API.Managers;
using Orders.Management.API.Models;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Xml.Serialization;

namespace Orders.Management.API.Helpers
{
    /// <summary>
    /// Helper class for order management
    /// </summary>
    public class OrderManagementHelper
    {
        /// <summary>
        /// Creates instance for processing input as per mode set in web.config
        /// </summary>
        /// <returns></returns>

        public static IProcessInput GetIProcessInputInstance()
        {
            IProcessInput instance = null;
            string mode = CommonHelper.ReadInputProcessMode();
            int processMode;
            if(int.TryParse(mode, out processMode))
            {
                switch(processMode)
                {
                    case 1:
                        instance = new CSVInputProcessor();
                        break;
                    // add more cases if we want to vary instance
                }
               
            }
            if(instance == null)
                instance = new CSVInputProcessor();
            return instance;
        }

        /// <summary>
        /// Reads orders and stores in a file
        /// </summary>
        public static void StoreOrders()
        {
            IProcessInput inputReader = GetIProcessInputInstance();

            //  Read all orders from file and store it in xml file
            inputReader.CreateXml(inputReader.FetchOrder());
        }

        public static OrderCollection GeOrderCollection()
        {
            OrderCollection orderCollection = null;
            try
            {
                XmlSerializer serializer = new XmlSerializer(typeof(OrderCollection));

                using (FileStream fs = new FileStream(CommonHelper.ReadXmlOutputDirectoryPath(), FileMode.OpenOrCreate))
                {
                    orderCollection = (OrderCollection)serializer.Deserialize(fs);
                }
            }
            catch(Exception ex)
            {
                CommonHelper.WriteErrorLog("Error while deserializing order data");
                CommonHelper.WriteErrorLog(ex.ToString());
            }
            return orderCollection;
        }        

    }
}