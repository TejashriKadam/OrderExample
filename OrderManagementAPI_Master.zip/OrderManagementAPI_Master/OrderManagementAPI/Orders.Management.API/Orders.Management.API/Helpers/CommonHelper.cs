﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Web;

namespace Orders.Management.API.Helpers
{
    /// <summary>
    /// Helper methods
    /// </summary>
    public class CommonHelper
    {
        /// <summary>
        /// returns input file path
        /// </summary>
        /// <returns></returns>
        public static string ReadInputFilePath()
        {
            return ReadKey(Constants.WebConfigKeys.InputFileDirectory);
        }
        /// <summary>
        /// returns file path to store xml of order collection
        /// </summary>
        /// <returns></returns>
        public static string ReadXmlOutputDirectoryPath()
        {
            return ReadKey(Constants.WebConfigKeys.XmlOutputDirectoryPath);
        }
        /// <summary>
        /// returns log file path
        /// </summary>
        /// <returns></returns>
        public static string ReadLogFilePath()
        {
            return ReadKey(Constants.WebConfigKeys.LogFilePath);
        }
        /// <summary>
        /// returns process mode from web.config to create instance of input processor
        /// </summary>
        /// <returns></returns>
        public static string ReadInputProcessMode()
        {
            return ReadKey(Constants.WebConfigKeys.InputProcessorMode);
        }
        /// <summary>
        /// logs message to file
        /// </summary>
        /// <param name="message">string message</param>
        public static void WriteErrorLog(string message)
        {
            StreamWriter sw = null;
            try
            {
                var fileStream = File.Open(string.Format(ReadLogFilePath(), DateTime.Now.Date.ToShortDateString()), FileMode.OpenOrCreate);
                sw = new StreamWriter(fileStream);
                sw.WriteLine(DateTime.Now.ToString() + ": " + message);
                fileStream.Close();
                sw.Flush();
                sw.Close();
            }
            catch
            {
            }
        }

        /// <summary>
        /// reads input key from web.config
        /// </summary>
        /// <param name="key">string key</param>
        /// <returns>string</returns>
        private static string ReadKey(string key)
        {
            try
            {
                return ConfigurationManager.AppSettings[key];
            }
            catch (Exception ex)
            {
                WriteErrorLog(string.Format("Exception while reading key-{0} from web.config", key));
                return string.Empty;

            }
        }
    }
}